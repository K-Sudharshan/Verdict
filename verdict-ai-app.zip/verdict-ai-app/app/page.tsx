import VerdictExperience from "@/components/experience/verdict-experience"

export default function Home() {
  return <VerdictExperience />
}
