# Verdict.AI — 3D Gallery & Shader Animation integration

This bundle contains two rebranded shadcn-style components plus demo pages,
ready to drop into a Next.js + Tailwind + TypeScript + shadcn/ui project.
All visible template branding ("Shadway", "Shader Animation") has been
replaced with **Verdict.AI**. Nothing inside the component logic itself
(variable names, comments, GLSL) needed to change — that's implementation
detail, not visible branding.

## 0. If you don't have a shadcn/Tailwind/TypeScript project yet

```bash
npx create-next-app@latest verdict-ai-app --typescript --tailwind --eslint --app --src-dir=false --import-alias "@/*"
cd verdict-ai-app
npx shadcn@latest init
```

During `shadcn init`, accept the defaults (or confirm) so components land in
`components/ui` and the `@/*` import alias points at the project root — the
demo files here import from `@/components/ui/...`, so this path matters.

If your project already exists but doesn't yet have shadcn wired up:

```bash
npx shadcn@latest init
```

**Why `/components/ui` matters:** shadcn's CLI, its generated `components.json`,
and every shadcn primitive you add later all assume components live at
`components/ui/<name>.tsx`. Dropping these files somewhere else breaks the
`@/components/ui/...` import paths used throughout the demo pages and in any
shadcn component you install afterward, and makes it harder for teammates
(and future shadcn CLI runs) to find things by convention.

## 1. Install dependencies

```bash
npm install three @react-three/fiber @react-three/drei framer-motion
npm install -D @types/three
```

`@react-three/fiber` and `@react-three/drei` require React 18+.

## 2. File layout in this bundle

```
components/ui/3d-gallery-photography.tsx     → default export InfiniteGallery (standalone, infinite-scroll version)
components/ui/shader-animation.tsx           → named export ShaderAnimation (standalone)
components/experience/cinematic-intro.tsx    → finite-duration gallery intro + transition-only shader flash
components/experience/verdict-experience.tsx → phase controller: intro → transition → landing
components/landing/landing-page.tsx          → the actual Verdict.AI landing page (nav, hero, features)
app/page.tsx                                 → mounts VerdictExperience — this is the real entry point
app/gallery-demo/page.tsx                    → standalone demo route for the raw gallery component
app/shader-demo/page.tsx                     → standalone demo route for the raw shader component
app/layout.tsx                               → root layout, Verdict.AI metadata
app/globals.css                              → Tailwind directives
```

### The cinematic intro → landing page experience

`app/page.tsx` renders `VerdictExperience`, which owns a single `phase` state
machine (`"intro" | "transition" | "landing"`):

- **`intro`** — `CinematicIntro` renders a *finite* version of the 3D gallery
  (accelerates, holds, decelerates to a stop over `introDuration` seconds,
  default 8s) inside an R3F `Canvas`, `z-20`, full opacity. Page scroll is
  locked. `LandingPage` is already mounted underneath at `z-10` but at
  opacity 0 — it exists in the DOM from the start, not created afterward.
- **`transition`** — fires once the gallery's internal progress hits 1. The
  intro layer's `Canvas` fades `opacity: 1 → 0` over `transitionDuration`
  (default 1.4s) while `LandingPage` simultaneously fades `opacity: 0 → 1`
  and its navbar/hero/features animate in with staggered `y` + opacity
  transitions — both layers are visible and overlapping during this window,
  never a hard cut or a blank frame between them. A `ShaderTransitionLayer`
  (the same GLSL as `shader-animation.tsx`) briefly overlays the dissolve at
  `mix-blend-mode: screen`, fading 0 → 0.55 → 0 across the same window — it's
  texture within the transition, never the destination.
- **`landing`** — once the intro's fade-out animation completes,
  `CinematicIntro` unmounts entirely (its R3F `Canvas` and animation loop are
  torn down), scroll is restored, and `LandingPage` is fully interactive.

Nothing here uses `setTimeout` to swap DOM layers — the intro's duration is
tracked in `useFrame` via a `progress` ref, and every fade is a real
`framer-motion` `animate()` transition with `onAnimationComplete` driving the
phase change.

**About the landing page content:** no landing page template was supplied
alongside the gallery/shader components, so `landing-page.tsx` is a
placeholder Verdict.AI page (nav links, hero copy, three feature cards) built
to prove the phase wiring end-to-end. Swap in your real copy, sections, and
components there — the `phase` prop and reveal animations don't need to
change when you do.

Copy `components/ui/*` into your project's `components/ui/` folder, and the
`app/*` files into your project's `app/` folder (merge `layout.tsx` and
`globals.css` with your existing ones rather than overwriting if you already
have content there).

## 3. Rebranding applied

| File | Original text | Replaced with |
|---|---|---|
| `app/gallery-demo/page.tsx` | `Shadway` hero heading | `Verdict.AI` |
| `app/shader-demo/page.tsx` | `Shader Animation` hero heading | `Verdict.AI` |
| `app/layout.tsx` | (n/a — new file) | page `<title>` set to `Verdict.AI` |

No other visible strings existed in either template (the rest is component
logic, prop names, CSS classes, and GLSL shader code, none of which is
user-facing branding).

## 4. Usage notes

**`InfiniteGallery`** (`components/ui/3d-gallery-photography.tsx`)
- Renders a scroll/keyboard-driven infinite 3D photo wall via
  `@react-three/fiber`. Requires a browser with WebGL; falls back to a plain
  image grid otherwise.
- Props: `images` (array of `string | { src, alt }`), `speed`, `zSpacing`,
  `visibleCount`, `falloff`, `fadeSettings`, `blurSettings`, `className`,
  `style`.
- Swap the sample Unsplash URLs in `app/gallery-demo/page.tsx` for your own
  imagery — remote images need `next.config.js` → `images.remotePatterns`
  configured for whichever hosts you use if you later switch to `next/image`
  (the component currently uses plain `<img>`/texture loading, so no config
  is required to run as-is).

**`ShaderAnimation`** (`components/ui/shader-animation.tsx`)
- Full-viewport animated WebGL shader background (`"use client"` — only use
  inside the App Router client boundary, or drop the directive if you're on
  Pages Router).
- No props; mount it and overlay content (like the `Verdict.AI` wordmark in
  the demo) with `absolute`/`z-10` positioning as shown.

## 5. Suggested placement

- `InfiniteGallery` fits best as a full-bleed hero or a `/gallery`/`/work`
  showcase route — it's heavy (WebGL + texture loads), so avoid stacking
  multiple instances on one page.
- `ShaderAnimation` works well as an ambient hero background behind a
  headline/CTA, similar to the demo page here. It runs a continuous
  `requestAnimationFrame` loop, so avoid mounting more than one at a time.

## 6. Icons

Neither component needs icons out of the box. If you extend the demo pages
with UI controls (play/pause, next/prev, etc.), use `lucide-react`:

```bash
npm install lucide-react
```
