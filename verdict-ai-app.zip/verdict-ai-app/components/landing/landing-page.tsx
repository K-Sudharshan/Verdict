"use client"

import { motion } from "framer-motion"
import type { ExperiencePhase } from "@/components/experience/cinematic-intro"

interface LandingPageProps {
  phase: ExperiencePhase
}

const NAV_LINKS = ["Product", "Docs", "Pricing", "About"]

const FEATURES = [
  {
    title: "Grounded answers",
    body: "Every response traces back to a source you can check, not a guess dressed up as one.",
  },
  {
    title: "Built for teams",
    body: "Share workspaces, review history, and keep everyone working from the same context.",
  },
  {
    title: "Runs where you work",
    body: "API, chat, and integrations that slot into the tools your team already uses.",
  },
]

export default function LandingPage({ phase }: LandingPageProps) {
  const revealed = phase !== "intro"

  return (
    <motion.div
      className="relative min-h-screen bg-black text-white"
      style={{ pointerEvents: phase === "landing" ? "auto" : "none" }}
      initial={false}
      animate={{ opacity: revealed ? 1 : 0 }}
      transition={{ duration: 1.4, ease: "easeInOut" }}
    >
      <motion.nav
        className="fixed top-0 z-10 flex w-full items-center justify-between px-6 py-5 md:px-12"
        initial={false}
        animate={{ opacity: revealed ? 1 : 0, y: revealed ? 0 : -16 }}
        transition={{ duration: 0.8, delay: revealed ? 0.3 : 0, ease: "easeOut" }}
      >
        <span className="font-serif text-xl italic tracking-tight">Verdict.AI</span>
        <div className="hidden gap-8 text-sm text-white/70 md:flex">
          {NAV_LINKS.map((link) => (
            <a key={link} href="#" className="transition hover:text-white">
              {link}
            </a>
          ))}
        </div>
        <button className="rounded-full border border-white/20 px-4 py-1.5 text-sm transition hover:border-white/40">
          Sign in
        </button>
      </motion.nav>

      <section className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <motion.h1
          className="max-w-3xl font-serif text-5xl italic leading-tight tracking-tight md:text-7xl"
          initial={false}
          animate={{ opacity: revealed ? 1 : 0, y: revealed ? 0 : 24 }}
          transition={{ duration: 0.9, delay: revealed ? 0.45 : 0, ease: "easeOut" }}
        >
          Judgment you can verify
        </motion.h1>
        <motion.p
          className="mt-6 max-w-xl text-lg text-white/70"
          initial={false}
          animate={{ opacity: revealed ? 1 : 0, y: revealed ? 0 : 16 }}
          transition={{ duration: 0.9, delay: revealed ? 0.6 : 0, ease: "easeOut" }}
        >
          Verdict.AI turns messy source material into answers you can trust — and trace.
        </motion.p>
        <motion.div
          className="mt-10 flex gap-4"
          initial={false}
          animate={{ opacity: revealed ? 1 : 0, y: revealed ? 0 : 16 }}
          transition={{ duration: 0.9, delay: revealed ? 0.75 : 0, ease: "easeOut" }}
        >
          <button className="rounded-full bg-white px-6 py-2.5 text-sm font-medium text-black transition hover:bg-white/90">
            Get started
          </button>
          <button className="rounded-full border border-white/20 px-6 py-2.5 text-sm transition hover:border-white/40">
            Watch demo
          </button>
        </motion.div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-8 px-6 pb-32 md:grid-cols-3">
        {FEATURES.map((feature, i) => (
          <motion.div
            key={feature.title}
            className="rounded-2xl border border-white/10 p-6"
            initial={false}
            animate={{ opacity: revealed ? 1 : 0, y: revealed ? 0 : 20 }}
            transition={{ duration: 0.7, delay: revealed ? 0.9 + i * 0.1 : 0, ease: "easeOut" }}
          >
            <h3 className="mb-2 text-lg font-medium">{feature.title}</h3>
            <p className="text-sm text-white/60">{feature.body}</p>
          </motion.div>
        ))}
      </section>

      <footer className="border-t border-white/10 px-6 py-10 text-center text-sm text-white/40">
        Verdict.AI
      </footer>
    </motion.div>
  )
}
