"use client"

import { useCallback, useState } from "react"
import CinematicIntro, { type ExperiencePhase } from "@/components/experience/cinematic-intro"
import LandingPage from "@/components/landing/landing-page"

const GALLERY_IMAGES = [
  "https://images.unsplash.com/photo-1741332966416-414d8a5b8887?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1754769440490-2eb64d715775?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1758640920659-0bb864175983?w=1200&auto=format&fit=crop&q=60",
  "https://plus.unsplash.com/premium_photo-1758367454070-731d3cc11774?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1746023841657-e5cd7cc90d2c?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1741715661559-6149723ea89a?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1725878746053-407492aa4034?w=1200&auto=format&fit=crop&q=60",
  "https://images.unsplash.com/photo-1752588975168-d2d7965a6d64?w=1200&auto=format&fit=crop&q=60",
]

export default function VerdictExperience() {
  const [phase, setPhase] = useState<ExperiencePhase>("intro")

  const handleIntroComplete = useCallback(() => setPhase("transition"), [])
  const handleTransitionComplete = useCallback(() => setPhase("landing"), [])

  return (
    <main className="relative min-h-screen bg-black">
      <LandingPage phase={phase} />

      {phase !== "landing" && (
        <CinematicIntro
          phase={phase}
          images={GALLERY_IMAGES}
          introDuration={8}
          transitionDuration={1.4}
          onIntroComplete={handleIntroComplete}
          onTransitionComplete={handleTransitionComplete}
        />
      )}
    </main>
  )
}
